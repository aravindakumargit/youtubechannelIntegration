//
//  AppDelegate.h
//  YoutubeChannelObjC
//
//  Created by cricket21 on 28/08/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

