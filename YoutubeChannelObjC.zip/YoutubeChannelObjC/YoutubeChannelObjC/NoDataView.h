//
//  NoDataView.h
//  CPL
//
//  Created by cricket21 on 29/04/16.
//  Copyright © 2016 cricket21. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoDataView : UIView
{
    
}

@property (strong, nonatomic)NSString *Message;
@property (strong, nonatomic)UILabel *lbl_Message;
@property (strong, nonatomic)UIButton *btn_Retry;
@property (assign, nonatomic)BOOL enableActivity;

-(instancetype)initWithFrame:(CGRect)frame AndMessage:(NSString *)message;
-(void)setHiddenActivity:(BOOL)hidden;

@end
