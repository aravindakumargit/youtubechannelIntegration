//
//  NoDataView.m
//  CPL
//
//  Created by cricket21 on 29/04/16.
//  Copyright © 2016 cricket21. All rights reserved.
//

#import "NoDataView.h"
#import "Activity.h"

@interface NoDataView ()
{
    Activity *activity;
}
@end

@implementation NoDataView
@synthesize Message = _Message;

-(id)init
{
    self = [super init];
    if (self) {
        // Custom Implementations..
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Custom Implementations..
        self.frame = frame;
        self.backgroundColor = [UIColor blackColor];
        _Message = @"No Data Found!!!";
        [self labelSetUp];
        [self activitySetUp];
    }
    
    return self;
}


-(instancetype)initWithFrame:(CGRect)frame AndMessage:(NSString *)message
{
    self = [super initWithFrame:frame];
    if (self) {
        // Custom Implementations..
        self.frame = frame;
        self.backgroundColor = [UIColor blackColor];
        _Message = message;
        [self labelSetUp];
        [self activitySetUp];
    }
    
    return self;
}

-(void)labelSetUp
{
    //CGPoint p = self.frame.origin;
    CGSize s = self.frame.size;
    self.lbl_Message = [[UILabel alloc]initWithFrame:CGRectMake(0, 70, s.width, 40)];
    self.lbl_Message.text = _Message;
    self.lbl_Message.textAlignment = NSTextAlignmentCenter;
    self.lbl_Message.textColor = [UIColor lightGrayColor];
    self.lbl_Message.font = [UIFont fontWithName:@"Square721BT-RomanExtended" size:15.0f];
    
   // NSLog(@"familyNames:%@",[UIFont familyNames]);
   // NSLog(@"%@",[UIFont fontNamesForFamilyName:@"Square 721"]);
    
    [self addSubview:self.lbl_Message];
}

-(NSString *)Message
{
    if (!_Message) {
        return @"";
    }else{
        return _Message;
    }
}

-(void)setMessage:(NSString *)Message
{
    if (Message != _Message) {
        _Message = Message;
        _lbl_Message.text = Message;
        [self setNeedsDisplay];
    }
}

-(void)activitySetUp
{
    CGRect r = self.frame;
    CGPoint p = CGPointMake(r.size.width/2, 50);
    activity = [[Activity alloc]initWithStyle:ActivityStyleMusicRed];
    activity.frame = CGRectMake(r.size.width/2, 30, 30, 30);
    activity.center = p;
    activity.ringThickness = 2.0;
    activity.circulatorTintColor = [UIColor blackColor];
    [self addSubview:activity];
    [activity startAnimating];
}

-(void)setHidden:(BOOL)hidden
{
    [super setHidden:hidden];
    
    if (hidden) {
        [activity stopAnimating];
    }else {
        [activity startAnimating];
    }
}

-(void)setHiddenActivity:(BOOL)hidden
{
    if (hidden) {
        [activity stopAnimating];
    }else {
        [activity startAnimating];
    }
    
    activity.hidden = hidden;
}

@end
