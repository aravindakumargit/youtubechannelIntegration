//
//  VideoDt.h
//  CPL
//
//  Created by cricket21 on 30/05/16.
//  Copyright © 2016 cricket21. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VideoDt : NSObject

@property (strong, nonatomic) NSString *title;
@property (strong, nonatomic) NSString *publishedAt;
@property (strong, nonatomic) NSString *thumbnail;
@property (strong, nonatomic) NSString *videoId;

@end
