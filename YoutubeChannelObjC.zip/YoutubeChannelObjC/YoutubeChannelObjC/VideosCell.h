//
//  VideosCell.h
//  CPL
//
//  Created by cricket21 on 29/03/16.
//  Copyright © 2016 cricket21. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VideosCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIWebView *webView;
@property (strong, nonatomic) IBOutlet UILabel *lbl_Title;
@property (strong, nonatomic) IBOutlet UILabel *lbl_Date;
@property (strong, nonatomic) IBOutlet UIImageView *img_Thumbnail;

@end
