//
//  VideosCell.m
//  CPL
//
//  Created by cricket21 on 29/03/16.
//  Copyright © 2016 cricket21. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "VideosCell.h"

@implementation VideosCell

- (void)awakeFromNib {
    // Initialization code
    self.backgroundColor = [UIColor clearColor];
    self.contentView.backgroundColor = [UIColor clearColor];
    _webView.hidden=YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
