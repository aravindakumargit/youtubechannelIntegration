//
//  ViewController.h
//  YoutubeChannelObjC
//
//  Created by cricket21 on 28/08/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YTPlayerView.h"
#import "VideoDt.h"
#import "VideosCell.h"
#import "UIImageView+WebCache.h"
#import "NoDataView.h"
@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property (strong,nonatomic) NSString *playlistId;
@property (strong,nonatomic) NSMutableArray *videosData;
@property (strong,nonatomic) NSString *nextPageToken;
@property (strong, nonatomic) IBOutlet UITableView *tbl_Videos;
@property (strong, nonatomic) IBOutlet YTPlayerView *YTPlayer;
@property (strong, nonatomic) IBOutlet UIWebView *webView;


@end

