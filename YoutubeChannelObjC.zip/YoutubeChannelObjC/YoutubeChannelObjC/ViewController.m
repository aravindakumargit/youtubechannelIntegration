//
//  ViewController.m
//  YoutubeChannelObjC
//
//  Created by cricket21 on 28/08/17.
//  Copyright © 2017 cricket21. All rights reserved.
//

#import "ViewController.h"
#define ChannelID @"UCt_Ml23H70ncuMlAgbIGlKA"
#define APIkey @"AIzaSyDc0Qlgc3AHb7WVqicTaZ-44ZWp7sKtNGY"
@interface ViewController ()

@end

@implementation ViewController
{
     NoDataView *vw_NoData;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _webView.hidden=YES;
    [self getChannelDetails];
}
-(void)viewDidAppear:(BOOL)animated{
    //[self.YTPlayer loadWithVideoId:@"M7lc1UVf-VE"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)getChannelDetails
{
    self.videosData = [NSMutableArray new];
    NSString *url = [NSString stringWithFormat:@"https://www.googleapis.com/youtube/v3/channels?part=contentDetails,snippet&id=%@&key=%@",ChannelID,APIkey];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    NSLog(@"the request is %@",request);
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (data != nil && error==nil) {
            NSError *err;
            NSDictionary *receivedData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&err];
            NSLog(@"rec data is %@",receivedData);
            if (err==nil) {
                @try {
                    _playlistId = receivedData[@"items"][0][@"contentDetails"][@"relatedPlaylists"][@"uploads"];
                    NSLog(@"the player id is %@",_playlistId);
                    NSLog(@"PlaylistID:%@",receivedData[@"items"][0][@"contentDetails"][@"relatedPlaylists"][@"uploads"]);
                }
                @catch (NSException *exception) {
                    _playlistId = @"UUt_Ml23H70ncuMlAgbIGlKA";
                    NSLog(@"expection: %@",exception.description);
                }
                @finally {
                 [self getPlaylistDetailsWithmaxResults:10 andPageToken:@""];
                }
            }
            else
            {
                NSLog(@"ERROR: %@",err.description);
            }
        }else{
            NSLog(@"ERROR: %@",error.description);
        }
    }];
    [dataTask resume];
}
- (void)getPlaylistDetailsWithmaxResults:(int)maxResults andPageToken:(NSString *)pageToken
{
    //self.nextPageToken = pageToken;
    NSString *TokenStr = (pageToken.length>0)?[NSString stringWithFormat:@"&pageToken=%@",pageToken]:@"";
    
    NSString *url = [NSString stringWithFormat:@"https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=%d&playlistId=%@&key=%@%@",maxResults,_playlistId,APIkey,TokenStr];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (data!=nil && error==nil) {
            NSError *err;
            NSDictionary *receivedData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&err];
            if (err==nil) {
                @try {
                    NSLog(@"detail %@",receivedData);
            if (![self.nextPageToken isEqual:receivedData[@"nextPageToken"]]) {
                self.nextPageToken = receivedData[@"nextPageToken"];
                NSArray *TempArr = receivedData[@"items"];
                for (NSDictionary *dt in TempArr) {
                NSDictionary *snippet = dt[@"snippet"];
                VideoDt *video = [VideoDt new];
                video.title = snippet[@"title"];
                video.publishedAt = snippet[@"publishedAt"];
                video.thumbnail = snippet[@"thumbnails"][@"default"][@"url"];
                video.videoId = snippet[@"resourceId"][@"videoId"];
                int position = [snippet[@"position"] intValue];
                if (position==0) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    NSLog(@"video is %@",video);
                [self LoadVideosDetails:video];
                });
                }
                [self.videosData addObject:video];
                [self setHiddenNoDataView];
                }
                }
                }
                @catch (NSException *exception) {
                    
                    NSLog(@"expection: %@",exception.description);
                }
                @finally {
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.tbl_Videos reloadData];
                    });
                    
                }
            }else {
                NSLog(@"ERROR: %@",err.description);
                [self setHiddenNoDataView];
            }
        }else {
            NSLog(@"ERROR: %@",error.description);
            [self setHiddenNoDataView];
        }
    }];
    
    [dataTask resume];
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.videosData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    cell = [tableView dequeueReusableCellWithIdentifier:@"VideosCell"];
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"VideosCell"];
    }
    VideoDt *video = (VideoDt*)self.videosData[indexPath.row];
    VideosCell *tempCell = (VideosCell*)cell;
    NSString *labelText = video.title;
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:labelText];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    [paragraphStyle setLineSpacing:5];
    [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [labelText length])];
    tempCell.lbl_Title.attributedText = attributedString;
    tempCell.lbl_Date.text =  [self AgoStringFromTime:video.publishedAt ForDateFormat:@"YYYY-MM-dd HH:mm:ss.SSSZ"];
    [tempCell.img_Thumbnail sd_setImageWithURL:[NSURL URLWithString:video.thumbnail]];
    // for loading more videos...
    if (indexPath.row==[self.videosData count]-1 && self.nextPageToken.length>0) {
        NSLog(@"video data count %lu and next page token is %lu",[self.videosData count]-1,(unsigned long)self.nextPageToken.length);
        [self getPlaylistDetailsWithmaxResults:10 andPageToken:self.nextPageToken];
    }else{
        NSLog(@"last count is %lu",(unsigned long)self.nextPageToken.length);
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self LoadVideosDetails:self.videosData[indexPath.row]];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10.0f;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *header;
    CGRect f = self.tbl_Videos.frame;
    header = [[UIView alloc]initWithFrame:CGRectMake(0, 0, f.size.width, 10)];
    header.backgroundColor = [UIColor clearColor];
    return header;
}

-(void)LoadVideosDetails:(VideoDt *)LtVideo
{
    NSDictionary *playerVars = @{@"showinfo":@0};
    NSLog(@"Ltvideo %@",LtVideo.videoId);
    [self.YTPlayer loadWithVideoId:LtVideo.videoId playerVars:playerVars];
}
- (NSString*)AgoStringFromTime:(NSString*)string ForDateFormat:(NSString *)dateFormat
{
    
    if (string.length>0) {
        string = [string stringByReplacingOccurrencesOfString:@"T" withString:@" "];
    }
    
    
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    [dateFormatter setDateFormat:dateFormat];
    
    NSDate *date = [dateFormatter dateFromString:string];
    
    NSDictionary *timeScale = @{@"sec"  :@1,
                                @"min"  :@60,
                                @"hr"   :@3600,
                                @"day"  :@86400,
                                @"week" :@605800,
                                @"month":@2629743,
                                @"year" :@31556926};
    NSString *scale;
    int timeAgo = 0-(int)[date timeIntervalSinceNow];
    if (timeAgo < 60) {
        scale = @"sec";
    } else if (timeAgo < 3600) {
        scale = @"min";
    } else if (timeAgo < 86400) {
        scale = @"hr";
    } else if (timeAgo < 605800) {
        scale = @"day";
    } else if (timeAgo < 2629743) {
        scale = @"week";
    } else if (timeAgo < 31556926) {
        scale = @"month";
    } else {
        scale = @"year";
    }
    
    timeAgo = timeAgo/[[timeScale objectForKey:scale] integerValue];
    NSString *s = @"";
    if (timeAgo > 1) {
        s = @"s";
    }
    
    
    return [NSString stringWithFormat:@"%d %@%@ ago", timeAgo, scale, s];
}
- (void)setHiddenNoDataView
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.videosData.count>0) {
            vw_NoData.hidden = YES;
            [vw_NoData setMessage:@""];
        }
        else{
            vw_NoData.hidden = NO;
            [vw_NoData setMessage:@"Videos not found"];
            [vw_NoData setHiddenActivity:YES];
        }
    });
}


@end
